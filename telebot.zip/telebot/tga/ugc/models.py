from django.db import models

class ADS(models.Model):
  stat = [
    ('True', 'Normal'),
    ('False', 'Blocked')
    ]
  user_id = models.TextField(verbose_name="user_id")
  status = models.CharField('status', choices=stat, max_length=50, blank=True, db_index=True)
  date = models.TextField(verbose_name="date")
  offers = models.TextField(verbose_name="offers")
  
class Meta:
  verbose_name = 'Рекламодатель'


class Offers(models.Model):
  user = models.TextField(verbose_name="user", unique=False)
  name = models.TextField(verbose_name="name")
  online = models.TextField(verbose_name="citi", unique=False)
  theme = models.TextField(verbose_name="theme", unique=False)
  subs = models.TextField(verbose_name="subs", unique=False)
  start = models.TextField(verbose_name="start", unique=False)
  stop = models.TextField(verbose_name="stop", unique=False)
  text = models.TextField(verbose_name="text", unique=False)
  cost = models.TextField(verbose_name="cost", unique=False)
  bloger = models.TextField(verbose_name="bloger", unique=False, default='0')
  
class Meta:
  verbose_name = 'Оффер'
  
class Moder(models.Model):
  user = models.TextField(verbose_name="user", unique=False)
  name = models.TextField(verbose_name="name")
  online = models.TextField(verbose_name="citi", unique=False)
  theme = models.TextField(verbose_name="theme", unique=False)
  subs = models.TextField(verbose_name="subs", unique=False)
  start = models.TextField(verbose_name="start", unique=False)
  stop = models.TextField(verbose_name="stop", unique=False)
  text = models.TextField(verbose_name="text", unique=False)
  cost = models.TextField(verbose_name="cost", unique=False)
  bloger = models.TextField(verbose_name="bloger", unique=False, default='0')
  
class Meta:
  verbose_name = u'Модерация'
  verbose_name_plural = u'Модерация'


class Blogers(models.Model):
  stat = [
    ('True', 'Normal'),
    ('False', 'Blocked')
    ]
  user_id = models.TextField(verbose_name='user_id')
  phone = models.TextField(verbose_name="phone")
  url = models.TextField(verbose_name="insta_name")
  status = models.CharField('status', choices=stat, max_length=50, blank=True, db_index=True)
  date = models.TextField(verbose_name="date")