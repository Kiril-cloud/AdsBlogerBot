from django import forms

from .models import ADS, Offers, Moder, Blogers


class ADSForm(forms.ModelForm):
  
  class Meta:
    model = ADS
    fields = {
      'id',
      'status', 
      'date', 
      'offers'
    }
    widgets = {
      'id': forms.TextInput,
      'status': forms.CharField, 
      'date': forms.DateInput,
      'offers': forms.TextInput
    }