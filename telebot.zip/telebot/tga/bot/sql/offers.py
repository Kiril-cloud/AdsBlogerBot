import sqlite3
import os


class Offers():
  def __init__(self):
    self.db = sqlite3.connect("bot.db")
    self.sql = self.db.cursor()
    print(os.getcwd())
    try:
      self.sql.execute('CREATE TRIGGER modered AFTER UPDATE OF cost ON ugc_moder BEGIN INSERT INTO ugc_offers SELECT * FROM ugc_moder WHERE rowid = (SELECT MAX(rowid) FROM ugc_moder); DELETE FROM ugc_moder WHERE rowid = (SELECT MAX(rowid) FROM ugc_moder); END;')
    except Exception as e:
      print(e)
    
  def getOffer(self, id, name):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE name == '{name}' and user == {id}""")
    result = self.sql.fetchone()
    id = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [id, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def getOfferModer(self, id, name):
    self.sql.execute(f"""SELECT * FROM ugc_moder WHERE name == '{name}' and user == {id}""")
    result = self.sql.fetchone()
    id = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [id, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def selectOffer(self, name):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE name == '{name}' """)
    result = self.sql.fetchone()
    user = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [user, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def getOfferM(self, id):
    self.sql.execute(f"""SELECT * FROM ugc_moder WHERE rowid == (SELECT MAX(rowid) FROM ugc_moder WHERE user == {id})""")
    result = self.sql.fetchone()
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [0, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def setName(self, id, name, start, mid):
    self.sql.execute(f"INSERT INTO ugc_moder VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (id+mid, id, name, 'Пусто', 'Пусто', 'Пусто', start, 'Пусто', 'Пусто', 'Пусто', 'Этот оффер еще никто не взял в работу'))
    self.db.commit()
    
  def setOnline(self, id, name, online):
    self.sql.execute(f"""UPDATE ugc_moder SET online = '{online}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setTheme(self, id, name, theme):
    self.sql.execute(f"""UPDATE ugc_moder SET theme = '{theme}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setSubs(self, id, name, subs):
    self.sql.execute(f"""UPDATE ugc_moder SET subs = '{subs}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setStop(self, id, name, stop):
    self.sql.execute(f"""UPDATE ugc_moder SET stop = '{stop}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setText(self, id, name, text):
    self.sql.execute(f"""UPDATE ugc_moder SET text = '{text}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setCost(self, id, name, cost):
    self.sql.execute(f"""UPDATE ugc_moder SET cost = '{cost}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def getName(self, id):
    if id != 0:
      self.sql.execute(f"SELECT name FROM ugc_offers WHERE user = {id}")
    else:
      self.sql.execute(f"SELECT name FROM ugc_offers")
    names = self.sql.fetchall()
    out = []
    for name in names:
      out.append(name[0])
      
    return out
    
  def getModerName(self, id):
    if id != 0:
      self.sql.execute(f"SELECT name FROM ugc_moder WHERE user = {id}")
    else:
      self.sql.execute(f"SELECT name FROM ugc_moder")
    names = self.sql.fetchall()
    out = []
    for name in names:
      out.append(name[0])
      
    return out
    
  def owner(self, name, id):
    self.sql.execute(f"SELECT user FROM ugc_offers WHERE name = '{name}' and user = {id}")
    if self.sql.fetchone() == None:
      self.sql.execute(f"SELECT user FROM ugc_moder WHERE name = '{name}' and user = {id}")
      if self.sql.fetchone() == None:
        return False
      else:
        return True
        
    else:
      return True
      
  def setBloger(self, name, id, url):
    self.sql.execute(f"""UPDATE ugc_offers SET bloger = '{url}' WHERE user = {id} and name = '{name}' """)
    self.db.commit()
    
  def getWork(self, url):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE bloger = '{url}' """)
    results = self.sql.fetchall()
    res = []
    for result in results:
      names = str(result[2])
      res.append(names)
    return res
    
  def delBloger(self, id, name):
    print(id, name)
    self.sql.execute(f"UPDATE ugc_offers SET bloger = '{'Этот оффер еще никто не взял в работу'}' WHERE user == {id} and name == '{name}' ")
    self.db.commit()