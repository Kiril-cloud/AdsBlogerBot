from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext

class reg_bloger(StatesGroup):
	phone = State()
	email = State()
	url = State()