from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

work_kb = InlineKeyboardMarkup(row_width=1)
answer = InlineKeyboardButton('Задать вопрос заказчику', callback_data='answer')
offer_compleet = InlineKeyboardButton('Отправить результат', callback_data='offer_compleet')
work_kb.add(answer, offer_compleet)