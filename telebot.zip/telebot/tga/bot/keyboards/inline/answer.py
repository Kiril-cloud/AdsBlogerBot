from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

answer_kb = InlineKeyboardMarkup(row_width=1)
ret = InlineKeyboardButton('Ответить', callback_data='return')
answer_kb.add(ret)