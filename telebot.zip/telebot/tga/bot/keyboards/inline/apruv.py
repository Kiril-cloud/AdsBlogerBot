from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

apruv = InlineKeyboardMarkup(row_width=1)
y = InlineKeyboardButton('Принять', callback_data='accept')
n = InlineKeyboardButton('Oтклонить', callback_data='reject')
apruv.add(y, n)