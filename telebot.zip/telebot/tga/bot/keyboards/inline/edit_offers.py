from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

edit_offers = InlineKeyboardMarkup(row_width=1)
online = InlineKeyboardButton('Город', callback_data = 'online')
theme = InlineKeyboardButton('Тематика', callback_data = 'theme')
subs = InlineKeyboardButton('Минимальное количество подписчиков', callback_data = 'subs')
stop = InlineKeyboardButton('Дата окончания', callback_data = 'stop')
text = InlineKeyboardButton('Текст', callback_data = 'text')
back = InlineKeyboardButton('Сохранить и выйти', callback_data = 'back')
edit_offers.add(online, theme, subs, stop, text, back)