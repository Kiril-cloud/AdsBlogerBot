from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

menu = InlineKeyboardMarkup(row_width=2)
ads = InlineKeyboardButton('Рекламодатель', callback_data='ads')
blog = InlineKeyboardButton('Блогер', callback_data='blog')
menu.add(ads, blog)