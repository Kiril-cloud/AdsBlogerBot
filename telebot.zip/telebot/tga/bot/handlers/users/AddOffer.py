from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp
from sql import Offers
from keyboards.inline import create_offer


@dp.callback_query_handler(text='add_offer')
async def add(c):
  try:
    offers = Offers()
    if c.data == 'add_offer':
      text = f'Название: Пусто\n Тематика: Пусто\n Город: Пусто\n Начало: Пусто\n Конец: Пусто\n Минимальное число подписчиков: Пусто\n Текст задания: Пусто'
      await c.message.edit_text(f'Заполните все полля. \n {text}', reply_markup=create_offer)
  except:
    pass
    