from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext

from loader import dp, bot
from states import work_st
from keyboards.inline import answer_kb, compleet_kb


w = work_st()


@dp.callback_query_handler(text='answer')
async def answer(c):
  w = work_st()
  id = c.message.text.split()[4] + 'p'
  id = id[1 : -1]
  await c.message.answer(f'#{id}\n Отправте ваш вопрос, мы перешлем его заказчику, начните ваше сообщение с <code>#{id}</code>:')
  await w.answer.set()

 
@dp.callback_query_handler(text='offer_compleet')
async def compleet(c):
  w = work_st()
  id = c.message.text.split()[4] + 'p'
  id = id[1 : -1]
  name = c.message.text[c.message.text.find("Название: ") + 10 : c.message.text.find("Тематика: ")]
  await c.message.answer(f'#{id}\n#{name}\n Отправте ссылку на результат вашей работы, начните ваше сообщение с <code>#{id}\n#{name}</code>:')
  await w.result.set()


@dp.message_handler(state=w.result)
async def answer(message: types.message, state: FSMContext):
  try:
    await state.finish()
    id = message.text.split()[0] + 'p'
    id = id[1 : -1]
    name = message.text.split()[1] + 'p'
    name = name[1 : -1]
    await bot.send_message(id, f'#{message.from_user.id}\n' + message.text, reply_markup=compleet_kb)
    await message.answer('Ваше сообщение отправленно! Скоро заказчик ответит на ваш вопрос.')
  except:
    await message.answer('Неверный формат!')
  
  
@dp.message_handler(state=w.answer)
async def answer(message: types.message, state: FSMContext):
  try:
    await state.finish()
    id = message.text.split()[0] + 'p'
    id = id[1 : -1]
    await bot.send_message(id, f'#{message.from_user.id}\n' + message.text + f'Начните ваше сообщение с #{message.from_user.id}', reply_markup=answer_kb)
    await message.answer('Результат отправлен! Оффер будет считаться выполненным ели заказчик подтвердит его выполнение.')
  except:
    await message.answer('Неверный формат!')